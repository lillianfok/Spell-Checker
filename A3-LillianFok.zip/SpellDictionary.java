import java.util.HashSet;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;
import java.util.ArrayList;

/**
 *  Class to store a spelling dictionary
 *  @author Lillian Fok
 *  @version Spring 2022
 */
public class SpellDictionary {
  /** Stores the dictionary words */
  private static HashSet<String> words;

  /** 
   *  Constructor sets up the set of words
   *  @param filename The word list file
   */
  public SpellDictionary(String filename) {
    words = new HashSet<String>();
    Scanner input = null;
    try {
      input = new Scanner(new File(filename));
      while (input.hasNextLine()) {
      String word = input.nextLine();
      words.add(word);
      //System.out.println(word);
      }
    } catch (FileNotFoundException e) {
      System.err.println("Cannot locate file.");
      System.exit(-1);
    }
    input.close();
  }

  public boolean containsWord(String word) {
    return words.contains(word);
  }  

  /*accepts an arraylist and returns a string */
  public String makeString(ArrayList<String> letters_array) {
    String word_string = "";
    for (String letter : letters_array) { //rewrite the array list into a string
      word_string += letter;
        }
      return word_string;
  }

  /* Take in one word and returns a list of possible words */
  public ArrayList<String> nearMisses(String word) {
    word = word.toLowerCase(); //parse it into lower case
    ArrayList<String> near_misses = new ArrayList<String>();
    if (this.containsWord(word)) {
      near_misses = null;
    } else {
      int num_letters = word.split("").length; //count how many letters
      String[] letters_list = word.split(""); //make a string list
      ArrayList<String> letters = new ArrayList<String>(); //create empty array list
      for (int i = 0; i <num_letters; i++) {
        letters.add(letters_list[i]); //read the string list into the 'letters' array list
      }

      //Deletion
      for (int x = 0; x < num_letters; x++) { 
        String test_char = letters.get(x); //retrieve the letter of interest
        letters.remove(x); //delete one character from arraylist location
        String lettersString = this.makeString(letters); //make it a string to check
        if (this.containsWord(lettersString)) {
          near_misses.add(lettersString); //add to near misses if a match
        }
        letters.add(x, test_char); //re insert letter of interest
      }

      //Insertion
      for (int y = 0; y < num_letters+1; y++) { //check each position plus one
        for (char character = 'a'; character <= 'z'; character++) {
          letters.add(y, Character.toString(character)); //at each position of the array list, loop through the alphabet
          String lettersString = this.makeString(letters);
          if (this.containsWord(lettersString)) {
            near_misses.add(lettersString);
          }
          letters.remove(y); //remove the test character
        } 
      }

      //Substitutions
      for (int z = 0; z < num_letters; z++) {
        for (char character = 'a'; character <= 'z'; character++) { //loop thru the alphabet
          String test_char = letters.get(z); //save the letter to be substituted
          letters.set(z, Character.toString(character)); //replace the letter in that spot
          String lettersString = this.makeString(letters);
          if (this.containsWord(lettersString)) { //check if in dictionary
            near_misses.add(lettersString);
          }
          letters.set(z, test_char); //replace the original character
        }
      }

      //Transpositions
      for (int x = 0; x < num_letters-1; x++) {
        String char1 = letters.get(x); //get first letter
        String char2 = letters.get(x+1); //get second letter
        letters.set(x, char2); //replace first spot w second letter
        letters.set(x+1, char1); //replace second spot w first letter
        String lettersString = this.makeString(letters);
        if (this.containsWord(lettersString)) { //check if in dictionary
            near_misses.add(lettersString);
        }
        letters.set(x, char1); //put letters where they were originally
        letters.set(x+1, char2);
      }

      //Split
      for (int y = 1; y < num_letters; y++) { //want to insert a space beginning at index 1
        letters.add(y, " "); //add blank space at index
        String lettersString = this.makeString(letters); //make it a string
        String[] splitWords = lettersString.split("\\s+"); //split the string into two words, returns a string array
        if (this.containsWord(splitWords[0]) & this.containsWord(splitWords[1])) {
          String word_pair = splitWords[0] + " " + splitWords[1];
          near_misses.add(word_pair);
        }
        letters.remove(y); //remove the blank space
      }
    } 
    /* process everything through a hashset to delete duplicates */
    HashSet<String> set = new HashSet<String>(near_misses);
    near_misses.clear();
    near_misses.addAll(set); 
    return near_misses;
  }
}
