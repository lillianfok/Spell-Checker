import java.util.*;
//import java.io.File;
//import java.io.FileNotFoundException;

/** 
* Class to accept input from the user and respond with spelling 
* suggestions 
*/

public class SpellChecker {

  public static void main(String[] args) {
    /* args are accepted in a string array format */
    SpellDictionary dict = new SpellDictionary("words.txt");
    //if (args.length == 0) {
    //  Scanner input = new Scanner(System.in);
    //  while (input.hasNextLine()) {
    //    String line = input.nextLine();
        //Defendant d = new Defendant(line);
        //System.out.println(d);
    //  }
    //  input.close();
    //}
    //else {
      for (String word : args) { //for each word, check and print message
        ArrayList<String> results = new ArrayList<String>();
        results = dict.nearMisses(word); 
        if (results.size() == 0) { //if near misses returns no corrections
          System.out.println("'"+word+"' is spelled correctly.");
        }
        else { //otherwise, take the results array and print it out nicely
          System.out.println("Not found: " +word);
          String printString = " Suggestions: ";
          for (String suggestion : results) {
            printString += suggestion + " ";
          }
          System.out.println(printString);
        }
      }
    //}
  }
}