class Main {
  public static void main(String[] args) {
    testSpellDictionary();
  }

  /* Test methods for each kind of near miss possibility */
  public static void testSpellDictionary() {
    SpellDictionary dict = new SpellDictionary("words.txt");
    //TestCode.beginTest("Near Misses Check");
    TestCode.runTest("Deletion", dict.nearMisses("hummble").contains("humble"));
    TestCode.runTest("Insertion", dict.nearMisses("qest").contains("quest"));
    TestCode.runTest("Substitutions", dict.nearMisses("shxllow").contains("shallow"));
    TestCode.runTest("Transpositions", dict.nearMisses("aslepe").contains("asleep"));
    TestCode.runTest("Splits", dict.nearMisses("redgreen").contains("red green"));
    //TestCode.concludeTest();
  }
}